"""
Importing Libraries
"""
import ctypes
from config import *
import time
import pyautogui as pg
import pytesseract
import pandas as pd
import cv2
import os


class OcrForAnthem:
    """
    A class to perform OCR on Anthem portal
    """

    def __init__(self):
        pass

    def fetch_system_path(self):
        """fetch the system path"""
        userName = os.getlogin()
        # creating the directory if not exist
        system_path = "C:\\" + userName + "\\Documents\\anthemproject"
        if not os.path.isdir(system_path):
            os.makedirs(system_path)
        return system_path

    def take_screen_shot(self):
        """Takes a screenshot, returns a screenshot path"""
        screenshot = pg.screenshot()
        screenshot_path = self.fetch_system_path() + "\\temp.png"
        screenshot.save(screenshot_path)
        return screenshot_path

    def get_ocr_data(self, img):
        """
        This function is responsible for perceiving what is on the screen
        :return: ocr result -> str
        """
        pytesseract.pytesseract.tesseract_cmd = tesseract_path
        conf = r'--oem 3'
        boxes = pytesseract.image_to_data(img, config=conf)
        box_list = []
        for x, b in enumerate(boxes.splitlines()):
            anno = {}
            if x != 0:
                b = b.split()
                if len(b) == 12:
                    x, y, w, h = int(b[6]), int(b[7]), int(b[8]), int(b[9])
                    cv2.rectangle(img, (x, y), (w + x, h + y), (205, 92, 92), 1)
                    cv2.putText(img, b[11], (x, y), cv2.FONT_HERSHEY_DUPLEX, 0.4, (205, 92, 92), 1)
                    anno['xmin'] = int(b[6])
                    anno['ymin'] = int(b[7])
                    anno['xmax'] = int(b[8]) + int(b[6])
                    anno['ymax'] = int(b[9]) + int(b[7])
                    anno['text'] = b[11]
                    box_list.append(anno)

        result = pd.DataFrame(box_list)
        with pd.option_context('display.max_rows', None,
                               'display.max_columns', None):
            print(result)
        return result

    def get_bgr2rgb_ocr_data(self):
        """
        This function is responsible for perceiving what is on the screen in colourful text
        :return: ocr result -> str
        """
        screenshot_path = self.take_screen_shot()
        img = cv2.imread(screenshot_path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        result = self.get_ocr_data(img=img)
        return result

    def get_gray_ocr_data(self):
        """
        This function is responsible for perceiving what is on the screen in gray text
        :return: ocr result -> str
        """
        screenshot_path = self.take_screen_shot()
        img = cv2.imread(screenshot_path)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        threshold = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        invert = 255 - threshold
        result = self.get_ocr_data(img=invert)
        return result

    def get_threshold_ocr_data(self):
        """
        This function is responsible for perceiving what is on the screen applying different thresholding techniques on the input image
        :return: ocr result -> str
        """
        screenshot_path = self.take_screen_shot()
        img = cv2.imread(screenshot_path)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        th = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 9)
        invert = 255 - th
        result = self.get_ocr_data(img=invert)
        return result

    def word_coordinate(self,coordinates):
        """
        This function is responsible for giving word coordinates
        :param coordinates:
        :return: x,y -> int(x,y)
        """
        print(coordinates)
        x1 = int(coordinates['xmin'])
        y1 = int(coordinates['ymin'])
        x2 = int(coordinates['xmax'])
        y2 = int(coordinates['ymax'])
        x = int((x2 + x1) / 2)
        y = int((y2 + y1) / 2)
        print(x, y)
        return x, y

    def check_text_on_page(self, text, ocr_function_no):
        """
        This function is responsible for checking a given text on webpage/reflection workspace
        :param text: str
        :param ocr_function_no: int
        :return: coordinate of text -> int
        """
        ck = False
        i = 0
        while ck is False or i != 3:  # to retake screenshots
            if ocr_function_no == 1:
                boxes = self.get_bgr2rgb_ocr_data()
            elif ocr_function_no == 2:
                boxes = self.get_gray_ocr_data()
            elif ocr_function_no == 3:
                boxes = self.get_threshold_ocr_data()
            crdnts = boxes.loc[boxes['text'] == text]
            print(crdnts)
            ck = text in boxes['text'].unique()
            i += 1
        if i == 3:
            ctypes.windll.user32.MessageBoxW(0, "Execution will be stopped."
                                                "\nRestart Program", "Text Not Found")
            exit()
        return crdnts

    def get_word_coordinate(self, text, ocr_function_no):
        """
        This function is responsible for getting a given text coordinate from webpage/reflection workspace
        :param text:
        :param ocr_function_no:
        :return:
        """
        ck = False
        # boxes = self.get_bgr2rgb_ocr_data()
        while ck is False:  # to retake screenshots
            if ocr_function_no == 1:
                boxes = self.get_bgr2rgb_ocr_data()
            elif ocr_function_no == 2:
                boxes = self.get_gray_ocr_data()
            elif ocr_function_no == 3:
                boxes = self.get_threshold_ocr_data()
            ck = text in boxes['text'].unique()
        return boxes

    def move_cursor_to_text(self, text):
        """
        This function is responsible for moving mouse cursor to given text
        :param text:
        :return: position
        """
        crdnts = self.check_text_on_page(text)
        a = self.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0], a[1], 1)
        pg.click()
        time.sleep(1)
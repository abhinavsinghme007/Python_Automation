"""
Importing Dependencies
"""
from config import *
from ocrforanthem import OcrForAnthem
from launchcitrixchrome import LaunchCitrixChrome
import time
import pyautogui as pg
from ..input_controller.keyboard import Keyboard
from logger import Logger
from utility import Utility


class LaunchPlm:
    """
    This class will launch PLM portal
    """
    def __init__(self):
        self.log = Logger(self.__class__.__name__)

    def open_plm(self):
        """This method will open PLM portal"""
        Utility.minimize_window(window_path="Reflection Workspace")
        time.sleep(2)
        self.log.info("Opening Browser")
        Utility.maximize_window(window_path="Claims Examiner")
        time.sleep(1)
        pg.click()
        time.sleep(1)
        with Keyboard.c.pressed(Keyboard.keys.ctrl):
            Keyboard.c.tap('t')
        time.sleep(1)
        pg.typewrite(plm_url, interval=0.02)  # shooting the web link of anthem
        Keyboard.c.tap(Keyboard.keys.enter)
        self.log.info("Opened PLM in Browser successfully")
        # check whether land on PLM page
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(text='Summary')
        pg.moveRel(-143, 30, 1)
        pg.click()
        time.sleep(1)
        Keyboard.c.tap(Keyboard.keys.page_up)
        time.sleep(2)
        ocr_for_anthem.move_cursor_to_text(text='DEMOGRAPHIC')  # click on search by Demographic data
        ocr_for_anthem.move_cursor_to_text(text='Tax-ID')
        ids = LaunchCitrixChrome.validate_dsscreen()
        pg.write(ids.tax_id)
        with Keyboard.c.pressed(Keyboard.keys.shift):
            Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        pg.write(ids.rndr_npi)
        time.sleep(1)
        pg.typewrite(['down'])
        time.sleep(1)
        ocr_for_anthem.move_cursor_to_text(text='Zip')
        pg.moveRel(483, 327, 1)
        pg.click()
        time.sleep(2)
        Keyboard.c.tap(Keyboard.keys.page_down)
        time.sleep(1)

    # extract Ticket number
    def copy_ticket(self):
        """This method copy ticket number"""
        ocr_for_anthem = OcrForAnthem()
        crdnts = ocr_for_anthem.move_cursor_to_text(text='Lifecycle')
        # copy BLNG SID
        boxes = ocr_for_anthem.get_gray_ocr_data(text='Case')
        index = boxes[boxes.text == 'Case'].index.values
        ticket_no = boxes.iloc[index - 2].text.values[0]
        print(ticket_no)

    def run(self):
        self.open_plm()
        self.copy_ticket()
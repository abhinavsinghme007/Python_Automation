"""
Importing Dependencies
"""
from ocrforanthem import OcrForAnthem
from config import *
import time
import pickle
import os
import ctypes
import pandas as pd
from ..input_controller.keyboard import Keyboard


class ImspSessionOne:
    """
    This class will open IMSP session one, read DCN Datasheet and paste DCN id
    """
    def __init__(self):
        pass

    def imsp_one(self):
        """ This function is responsible for opening imsp session one"""
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(text="SELECT")
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        # type cc
        for i in 'cc':
            Keyboard.c.tap(i)
            time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.enter)
        ocr_for_anthem.move_cursor_to_text(text="SELECT")
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        # type aa
        for i in 'aa':
            Keyboard.c.tap(i)
            time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.enter)

    def get_dcn(self):
        """
        This function will read dcn id from datasheet
        """
        df1 = pd.read_excel(dcn_datasheet)
        df1 = df1['DCN']
        # We have the list of dcn ids
        print(df1)
        with pd.option_context('display.max_rows', None,
                               'display.max_columns', None):

            print(df1)

        if os.path.isfile("variableStoringFile.dat"):
            dcn_no = pickle.load(open("variableStoringFile.dat", "rb"))
            print(dcn_no)
            if dcn_no == len(df1):
                ctypes.windll.user32.MessageBoxW(0, "Change DCN IDs in dcn_datasheet.xlsx\nProgram Execution will be "
                                                    "stopped.\ndcn_no resets to 0", "ALl DCN Used")
                dcn_no = 0
                pickle.dump(dcn_no, open("variableStoringFile.dat", "wb"))
                exit()
        else:
            dcn_no = 0
            pickle.dump(dcn_no, open("variableStoringFile.dat", "wb"))
        print(df1[dcn_no])
        return df1[dcn_no]

    def claims_inquiry(self):
        """
        This function is responsible for entering DCN Id from datasheet at required field
        :return:
        """
        dcn_id = str(self.get_dcn())
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(text='(DCN):')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(0.5)
        for i in dcn_id:
            Keyboard.c.tap(i)
            time.sleep(0.5)
        time.sleep(1)
        print(dcn_id)
        Keyboard.c.tap(Keyboard.keys.enter)

    def copy_dcn(self):
        """
        This function is responsible for copying DCN numbers, Tax ID
        :return:
        """
        # copy dcn, un, tax id using ocr
        ocr_for_anthem = OcrForAnthem()
        boxes = ocr_for_anthem.get_word_coordinate(text='DCN')
        index = boxes[boxes.text == 'DCN'].index.values

        # copy dcn id
        dcn1 = boxes.iloc[index + 1].text.values[0]
        dcn2 = boxes.iloc[index + 2].text.values[0]
        dcn3 = boxes.iloc[index + 3].text.values[0]
        dcn = dcn1 + dcn2 + dcn3
        print(dcn)

        # copy tax id
        index = boxes[boxes.text == 'TAX'].index.values
        tax_id_1 = boxes.iloc[index + 2].text.values[0]
        print(tax_id_1)

        # copy un id
        index = boxes[boxes.text == 'Q'].index.values
        un = boxes.iloc[index + 1].text.values[0]
        unit_split = un[:2]
        print(unit_split)

        # check first two letters if 93
        status_check = un[-2:]
        print(status_check)

    def run(self):
        self.imsp_one()
        self.claims_inquiry()

"""
Importing Dependencies
"""
import subprocess as sp
from config import *
from ocrforanthem import OcrForAnthem
from logger import Logger
import pyautogui as pg
import pygetwindow as gw
from ..input_controller.keyboard import Keyboard
pg.FAILSAFE = True


class LoginToAnthem:
    """A class to launch Anthem portal"""

    def __init__(self):
        self.log = Logger(self.__class__.__name__)

    def open_browser(self):
        """
        This function is responsible for launching the  Chrome browser
        """
        self.log.info("Opening Browser")
        sp.Popen(chrome_path)
        gw.getActiveWindow()
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.check_text_on_page(text="New", ocr_function_no=1)
        pg.typewrite(anthem_url, interval=0.02)  # opening anthem portal
        Keyboard.c.tap(Keyboard.keys.enter)
        self.log.info("Browser opened successfully")

    def login_page(self):
        """
        This function will enter username, password and will click on submit button
        :return:
        """
        ocr_for_anthem = OcrForAnthem()
        crdnts = ocr_for_anthem.check_text_on_page(text=Dict["login"][0], ocr_function_no=1)  # enter username
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] + 122, a[1] + 84, 0.5)
        pg.click()
        self.log.info("Entering Username")
        pg.write(citrix_id)
        self.log.info("Entered Username successfully")
        pg.moveTo(a[0] + 122, a[1] + 160, 0.5)
        pg.click()
        self.log.info("Entering password")
        pg.write(citrix_pwd)
        self.log.info("Entered password successfully")
        pg.moveTo(a[0] + 109, a[1] + 240, 0.5)
        pg.doubleClick()  # accept terms & conditions
        pg.moveTo(a[0] + 297, a[1] + 331, 0.5)
        pg.doubleClick()  # click on submit button

    def select_auth_device(self):
        """
        This function is responsible for selecting authorization device by putting required value and click on submit
        :return:
        """
        ocr_for_anthem = OcrForAnthem()
        crdnts = ocr_for_anthem.check_text_on_page(text=Dict["select_auth_device"][0] or Dict["select_auth_device"][2])
        a = OcrForAnthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] - 300, a[1] + 100, 0.5)
        pg.click()
        pg.write(auth_code)  # select authorization device
        pg.moveTo(a[0], a[1] + 200, 0.5)
        pg.click()

    def launch_pingid(self):
        """
        This function is responsible for launching Ping ID application and copy the passcode
        :return:
        """
        self.log.info("Opening Ping ID")
        sp.Popen(pingid_path)  # opening PingID application
        ocr_for_anthem = OcrForAnthem()
        crdnts = ocr_for_anthem.check_text_on_page(text=Dict["launch_pingID"][2])
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] + 26, a[1] + 352, 2)
        pg.click()
        self.log.info("Ping ID opened successfully")
        pg.getActiveWindow().close()

    def paste_passcode(self):
        """
        This function is responsible for pasting passcode and click in submit button
        :return:
        """
        ocr_for_anthem = OcrForAnthem()
        crdnts = ocr_for_anthem.check_text_on_page(text=Dict["Passcode"][1])
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] - 291, a[1] + 66, 0.5)
        pg.click()
        with pg.hold('ctrl'):
            pg.press(['v'])
        pg.moveTo(a[0], a[1] + 175, 0.5)
        pg.click()

    def run(self):
        self.open_browser()
        self.login_page()
        self.select_auth_device()
        self.launch_pingid()
        self.paste_passcode()

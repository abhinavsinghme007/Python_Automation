#
# Created On Thu Nov 24 2022
#
# Copyright (c) 2022 Exela Technologies Pvt Ltd
#
# Author: Ganesh [Python Developer]
#

from logintoanthem import LoginToAnthem
from reflectionworkspace import LaunchReflectionWorkspace
from utility import Utility
from imsp_one import ImspSessionOne
from imsp_two import ImspSessionTwo
from imsp_three import ImspSessionThree


if __name__ == "__main__":
    # code execution starts from here
    utility = Utility()
    utility.minimize_window(window_path="Anthem_EST")

    # login to Anthem portal
    login_to_anthem = LoginToAnthem()
    login_to_anthem.run()

    # Launching to reflection workspace
    reflection_workspace = LaunchReflectionWorkspace()
    reflection_workspace.run()

    # opening IMSP session 1
    imsp_one = ImspSessionOne()
    imsp_one.run()

    #opening IMSP session 2
    imsp_two = ImspSessionTwo()
    imsp_two.run()

    #opening IMSP session3
    imsp_three = ImspSessionThree()
    imsp_three.run()







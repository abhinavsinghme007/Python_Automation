"""
Importing Dependencies
"""
from ocrforanthem import OcrForAnthem
from config import *
from utility import Utility
from logger import Logger
import time
import pyautogui as pg
import pygetwindow as gw
from ..input_controller.keyboard import Keyboard


class LaunchReflectionWorkspace:
    """
    A class to launch reflection workspace through citrix receiver gateway
    """

    def __init__(self):
        self.log = Logger(self.__class__.__name__)

    def launch_citrix_receiver(self):
        """
        This function is responsible for launching reflection workspace
        :return:
        """
        ocr_for_anthem = OcrForAnthem()
        utility = Utility()
        ocr_for_anthem.move_cursor_to_text(Dict["Citrix_Receiver"][0])
        time.sleep(3)  # screen is sliding so to get proper position 4 sec pause is required
        crdnts = ocr_for_anthem.get_bgr2rgb_ocr_data(text=Dict["Citrix_Receiver"][1])
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.click(a[0], a[1] - 80, 1)
        time.sleep(2)  # time sleep needed here to stabilize the process
        utility.minimize_window(window_path="Citrix Receiver")

    def launch_winca(self):
        """
        This function is responsible for launching winca application
        :return:
        """
        gw.getActiveWindow()
        ocr_for_anthem = OcrForAnthem()
        crdnt = ocr_for_anthem.get_bgr2rgb_ocr_data(text=Dict["winca"][0])
        a = ocr_for_anthem.word_coordinate(coordinates=crdnt)
        time.sleep(2)
        crdnts = ocr_for_anthem.get_bgr2rgb_ocr_data(text=Dict["winca"][1])
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0], a[1] + 150, 1)
        pg.click()

    def type_lssl(self):
        """
        This function will type l ssl at the required position
        :return:
        """
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(text=Dict["ssl"][1])
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(0.5)
        self.log.info("Typing l ssl command")
        Keyboard.c.type("l ssl")
        time.sleep(1)
        Keyboard.c.tap(Keyboard.keys.enter)
        self.log.info("Typed l ssl command successfully")

    def super_session(self):
        """
        This function is responsible for entering User Id and password for mainframe application
        :return:
        """
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(text=Dict["super_session"][0])
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        # entering userid
        self.log.info("Entering mainframe username")
        for i in rfw_id:
            Keyboard.c.tap(i)
            time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.tab)
        self.log.info("Entered mainframe username successfully")
        time.sleep(1)
        # entering password
        self.log.info("Entering mainframe password")
        for j in rfw_pwd:
            Keyboard.c.tap(j)
            time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.enter)
        self.log.info("Entered mainframe password successfully")

    def select_imsp(self):
        """
        This function will select three different imsp session for further process
        :return:
        """
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(text=Dict["imsp"][3])
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.tap('s')

        ocr_for_anthem.move_cursor_to_text(text=Dict["imsp"][1])
        with Keyboard.c.pressed(Keyboard.keys.shift):
            Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.tap('s')

        ocr_for_anthem.move_cursor_to_text(text=Dict["imsp"][2])
        with Keyboard.c.pressed(Keyboard.keys.shift):
            Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.tap('s')
        time.sleep(1)
        Keyboard.c.tap(Keyboard.keys.enter)

    def run(self):
        self.launch_citrix_receiver()
        self.launch_winca()
        self.type_lssl()
        self.super_session()
        self.select_imsp()
        utility = Utility()
        utility.pause_break()
        utility.type_clmvinup()


"""
Importing Dependencies
"""
from ocrforanthem import OcrForAnthem
from utility import Utility
from launchcitrixchrome import LaunchCitrixChrome
from launch_plm import LaunchPlm
import time
from ..input_controller.keyboard import Keyboard


class ImspSessionThree:
    """
    This class will open Imps session three, and extract Rendering SID and Billing SID
    """
    def __init__(self):
        pass

    def imsp_three(self):
        """ This method will launch IMPS session three"""
        utility = Utility()
        ocr_for_anthem = OcrForAnthem()
        utility.maximize_window(window_path="Reflection Workspace")
        ocr_for_anthem.move_cursor_to_text(text='PROF')
        utility.page_down()
        utility.page_down()
        utility.pause_break()
        utility.type_clmvinup()

        ocr_for_anthem.move_cursor_to_text('CLMVINUP')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)

        # type pa
        for i in 'pa':
            Keyboard.c.tap(i)
            time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.enter)

        # type s in front of Individual
        ocr_for_anthem.move_cursor_to_text('ORGANIZATION')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.tap('s')
        time.sleep(1)
        Keyboard.c.tap(Keyboard.keys.enter)

        # type National state code
        ocr_for_anthem.move_cursor_to_text('MI')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        na_state = LaunchCitrixChrome.natl_state_check()
        for i in na_state.natl_state:
            Keyboard.c.tap(i)
            time.sleep(0.3)

        # type 33
        ocr_for_anthem.move_cursor_to_text('ALT')
        Keyboard.c.tap(Keyboard.keys.tab)
        Keyboard.c.type('33')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)

        # paste RNDR_NPI
        npi = LaunchCitrixChrome.validate_dsscreen()
        for i in npi.rndr_npi:
            c.tap(i)
            time.sleep(0.3)

        # type SRCH FRM date
        ocr_for_anthem.move_cursor_to_text('SRCH')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.type('010181')
        Keyboard.c.tap(Keyboard.keys.enter)
        time.sleep(1)

        # select record
        boxes = ocr_for_anthem.get_word_coordinate(text='INDIVIDUAL')  # change est
        st_name = LaunchCitrixChrome.copy_tbr_id()
        state = st_name.state_name in boxes['text'].unique()
        print(state)

        if state is True:
            ocr_for_anthem.move_cursor_to_text(text=st_name.state_name)
            with Keyboard.c.pressed(Keyboard.keys.shift):
                Keyboard.c.tap(Keyboard.keys.tab)
            time.sleep(1)
            Keyboard.c.tap('s')
            Keyboard.c.tap(Keyboard.keys.enter)
        else:
            tax = LaunchCitrixChrome.copy_tbr_id()
            state = tax.tax_id in boxes['text'].unique()
            print(state)
            if state is True:
                ocr_for_anthem.move_cursor_to_text(text=tax.tax_id)
                with Keyboard.c.pressed(Keyboard.keys.shift):
                    Keyboard.c.tap(Keyboard.keys.tab)
                time.sleep(1)
                Keyboard.c.tap('s')
                Keyboard.c.tap(Keyboard.keys.enter)

    def copy_rndr_sid(self):
        """ This method will copy Rendering SID """
        ocr_for_anthem = OcrForAnthem()
        crdnts = ocr_for_anthem.get_gray_ocr_data(text='INDIVIDUAL')
        # copy RNDR SID
        boxes = ocr_for_anthem.get_word_coordinate(text='OWNR')
        index = boxes[boxes.text == 'OWNR'].index.values
        rndr_sid = boxes.iloc[index - 1].text.values[0]
        print(rndr_sid)
        utility = Utility()
        utility.page_down()
        time.sleep(1)
        utility.page_down()
        time.sleep(1)
        # paste RNDR SID
        crdnts = ocr_for_anthem.get_gray_ocr_data(text='SUPPORTING')
        ocr_for_anthem.move_cursor_to_text(text='ATTN')
        with Keyboard.c.pressed(Keyboard.keys.shift):
            Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        for i in rndr_sid:
            Keyboard.c.tap(i)
            time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.enter)
        time.sleep(1)
        utility.page_down()
        time.sleep(1)
        crdnts = ocr_for_anthem.get_gray_ocr_data(text='INDIVIDUAL')
        Keyboard.c.tap(Keyboard.keys.f4)
        ocr_for_anthem.move_cursor_to_text(text='AFFTYP:')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.type('1918')
        Keyboard.c.tap(Keyboard.keys.enter)
        time.sleep(1)
        Keyboard.c.tap('s')
        Keyboard.c.tap(Keyboard.keys.enter)

    def copy_blng_sid(self):
        """" This mehtod will copy Billing SID"""
        ocr_for_anthem = OcrForAnthem()
        crdnts = ocr_for_anthem.get_gray_ocr_data(text='ORG')
        # copy BLNG SID
        boxes = ocr_for_anthem.get_word_coordinate(text='OWNR')
        index = boxes[boxes.text == 'OWNR'].index.values
        blng_sid = boxes.iloc[index - 1].text.values[0]
        print(blng_sid)
        utility = Utility()
        utility.page_down()
        time.sleep(1)
        utility.page_down()
        time.sleep(1)
        # paste BLNG SID
        crdnts = ocr_for_anthem.get_gray_ocr_data(text='SUPPORTING')
        ocr_for_anthem.move_cursor_to_text(text='ATTN')
        with Keyboard.c.pressed(Keyboard.keys.shift):
            Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        with Keyboard.c.pressed(Keyboard.keys.shift):
            Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        for i in blng_sid:
            Keyboard.c.tap(i)
            time.sleep(0.3)
        Keyboard.c.tap(Keyboard.keys.enter)
        ocr_for_anthem.move_cursor_to_text(text='LOG:')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.tap('l')
        Keyboard.c.tap(Keyboard.keys.enter)

    def check_est_edit(self,text):
        """ This method will check claim has EST edit or not"""
        ocr_for_anthem = OcrForAnthem()
        boxes = ocr_for_anthem.get_word_coordinate(text)
        est = 'EST' in boxes['text'].unique()
        return est

    def run(self):
        self.imsp_three()
        self.copy_rndr_sid()
        self.copy_blng_sid()
        est = self.check_est_edit(text='PROFESSIONAL')
        if est is True:
            plm = LaunchPlm()
            plm.run()
        else:
            ocr_for_anthem = OcrForAnthem()
            ocr_for_anthem.move_cursor_to_text(text='LOG')
            Keyboard.c.tap(Keyboard.keys.tab)
            time.sleep(1)
            Keyboard.c.tap('l')
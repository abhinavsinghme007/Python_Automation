from pynput import keyboard

class Keyboard:
    '''
    Keyboard controller class.
    '''
    c = keyboard.Controller()
    keys = keyboard.Key
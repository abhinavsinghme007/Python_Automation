"""
Importing Dependencies
"""
import pygetwindow as gw
from ocrforanthem import OcrForAnthem
import time
from config import *
from pynput import keyboard
c = keyboard.Controller()
keys = keyboard.Key


class Utility:
    """
    A class consist of utility methods
    """

    def __init__(self):
        pass

    def minimize_window(self, window_path):
        """Function to minimize any window"""
        window = gw.getWindowsWithTitle(window_path)[0]
        window.minimize()

    def maximize_window(self, window_path):
        """Function to maximize any window"""
        window = gw.getWindowsWithTitle(window_path)[0]
        window.maximize()

    def pause_break(self):
        """This function will press pause break key from keyboard"""
        ocr_for_anthem = OcrForAnthem()
        crdnts = ocr_for_anthem.get_bgr2rgb_ocr_data(text=Dict["pause_break"][0])
        c.tap(keys.pause)
        time.sleep(0.5)

    def page_down(self):
        """This function will press page down key"""
        c.tap(keys.page_down)
        time.sleep(0.5)

    def type_clmvinup(self):
        """This function will type clmvinup<space>"""
        for k in 'clmvinup':
            c.tap(k)
            time.sleep(0.5)
        c.tap(keys.space)
        time.sleep(0.5)
        c.tap(keys.enter)

"""
Importing Dependencies
"""
from ocrforanthem import OcrForAnthem
from utility import Utility
from imsp_one import ImspSessionOne
from launch_wcf import LaunchWcf
from launchcitrixchrome import LaunchCitrixChrome
import time
import pickle
import ctypes
from ..input_controller.keyboard import Keyboard


class ImspSessionTwo:
    """
    This class will open IMSP session Two, will check whether claim is in 93 status or not
    """
    def __init__(self):
        pass

    def imsp_two(self):
        """ This method will open Imsp session 2"""
        utility = Utility()
        utility.page_down()
        utility.pause_break()
        utility.type_clmvinup()

        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(text='SELECT')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)

        # type aa
        for i in 'aa':
            Keyboard.c.tap(i)
            time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.enter)

        ocr_for_anthem.move_cursor_to_text(text='SELECT')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)

        # type aa
        for i in 'aa':
            Keyboard.c.tap(i)
            time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.enter)

    def check_93_status(self):
        """
        This method will check whether claim is in 93 status or not
        :return:
        """
        # copy dcn, un, tax id using ocr
        ocr_for_anthem = OcrForAnthem()
        boxes = ocr_for_anthem.get_word_coordinate(text='DCN')
        index = boxes[boxes.text == 'DCN'].index.values
        # copy dcn id
        global dcn1, dcn2, dcn3, dcn, tax_id_1, un, unit_split, status_check
        dcn1 = boxes.iloc[index + 1].text.values[0]
        dcn2 = boxes.iloc[index + 2].text.values[0]
        dcn3 = boxes.iloc[index + 3].text.values[0]
        dcn = dcn1 + dcn2 + dcn3
        print(dcn)
        # copy tax id
        index = boxes[boxes.text == 'TAX'].index.values
        tax_id_1 = boxes.iloc[index + 2].text.values[0]
        print(tax_id_1)
        # copy un id
        index = boxes[boxes.text == 'DCN'].index.values
        pa_or_pm = boxes.iloc[index - 1].text.values[0]
        print("************************************************************************************************")
        print(pa_or_pm)
        if pa_or_pm == "PA" or pa_or_pm == "PM":
            index = boxes[boxes.text == 'Q'].index.values
            un = boxes.iloc[index + 1].text.values[0]
            unit_split = un[:2]
            print(unit_split)
            status_check = un[-2:]
            while status_check != '93':
                print('true')
                print(un[-2:])
                dcn_no = pickle.load(open("variableStoringFile.dat", "rb"))
                dcn_no = dcn_no + 1
                pickle.dump(dcn_no, open("variableStoringFile.dat", "wb"))
                ocr_for_anthem.move_cursor_to_text(text='N-DCN')
                Keyboard.c.tap(Keyboard.keys.tab)
                imsp_one = ImspSessionOne()
                dcn_id = imsp_one.get_dcn()
                for i in dcn_id:
                    Keyboard.c.press(i)
                time.sleep(2)
                Keyboard.c.tap(Keyboard.keys.enter)
                time.sleep(2)
                imsp_one.copy_dcn()
            self.imsp_two()
        else:
            ctypes.windll.user32.MessageBoxW(0, "DCN is not in PA & PM STATE\n program is stopped", "CODE EXIT")
            exit()

    def ddc_ini_screen(self):
        """
        This method will get the coordinates of UN ID and paste the value
        :return:
        """
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(text='UN')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.tap(unit_split[0])
        time.sleep(0.5)
        Keyboard.c.tap(unit_split[1])
        # pass the command s in change claim
        ocr_for_anthem.move_cursor_to_text(text='CHANGE')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.tap('s')

        # paste dcn
        ocr_for_anthem.move_cursor_to_text(text='CHANGE/INQUIRY/RE-KEY')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)

        for i in dcn1:
            Keyboard.c.tap(i)
            time.sleep(0.5)

        for j in dcn2:
            Keyboard.c.tap(j)
            time.sleep(0.5)

        for k in dcn3:
            Keyboard.c.tap(k)
            time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.enter)

    def type_35(self):
        """type 35 at the right bottom of screen"""
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(text='EXT')
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(0.5)
        Keyboard.c.tap(Keyboard.keys.tab)
        time.sleep(1)
        Keyboard.c.type('35')
        Keyboard.c.tap(Keyboard.keys.enter)

    def supporting_data_screen(self):  # check whether land on supporting Data screen
        """
        This method is responsible to capture Tax Id, Billing NPI and Rendering NPI
        :return:
        """
        ocr_for_anthem = OcrForAnthem()
        crdnts = ocr_for_anthem.get_gray_ocr_data(text='SUPPORTING')

        # copy Billing NPI using ocr
        boxes = ocr_for_anthem.get_word_coordinate(text='ORDR')
        index = boxes[boxes.text == 'ORDR'].index.values
        self.blng_npi_1 = boxes.iloc[index - 4].text.values[0]
        print(self.blng_npi_1)
        if self.blng_npi_1 == 'NPI':
            self.blng_npi_1 = ""

        # copy Rendering NPI
        self.rndr_npi_1 = boxes.iloc[index - 1].text.values[0]
        print(self.rndr_npi_1)
        if self.rndr_npi_1 == 'NPI':
            self.rndr_npi_1 = ""

        # copy National state
        boxes = ocr_for_anthem.get_word_coordinate(text='NATL')
        index = boxes[boxes.text == 'NATL'].index.values
        self.natl_state1 = boxes.iloc[index + 2].text.values[0]
        print(self.natl_state1)

    def check_claim_type(self):
        """This method will take a screenshot to check est edit."""
        ocr_for_anthem = OcrForAnthem()
        boxes = ocr_for_anthem.get_gray_ocr_data(text='EST')  # change est
        est = 'EST' in boxes['text'].unique()
        print(est)

        paper = ['R', 'L', 'Q']
        if est is True:
            print('est is present')
            if dcn.isdigit() is False:
                n_dcn = "20" + dcn
                print(n_dcn)
                print(n_dcn[7:8])
                if any(char in paper for char in n_dcn[7:8]):
                    print(True)
                    wcf = LaunchWcf()
                    wcf.open_wcf(text=n_dcn, blng_npi=self.blng_npi_1, rndr_npi=self.rndr_npi_1, state=self.natl_state1, taxid=self.tax_id_1)
                else:
                    # print(False)
                    ciw = LaunchCitrixChrome()
                    ciw.run()
            else:
                n_dcn = dcn
                print(n_dcn)
                wcf = LaunchWcf()
                wcf.open_wcf(text=n_dcn, blng_npi=self.blng_npi_1, rndr_npi=self.rndr_npi_1, state=self.natl_state1, taxid=self.tax_id_1)
        else:
            print('est is not present')

    def run(self):
        self.imsp_two()
        self.check_93_status()
        self.ddc_ini_screen()
        self.type_35()
        self.supporting_data_screen()
        utility = Utility()
        utility.page_down()
        utility.page_down()
        self.check_claim_type()
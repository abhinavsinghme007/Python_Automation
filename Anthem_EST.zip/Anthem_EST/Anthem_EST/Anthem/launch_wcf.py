"""
Importing Dependencies
"""
from config import *
from ocrforanthem import OcrForAnthem
from logintoanthem import LoginToAnthem
from utility import Utility
import pyautogui as pg
import boto3
import cv2
import time
from PIL import Image, ImageDraw, ExifTags, ImageColor
from ..input_controller.keyboard import Keyboard


class LaunchWcf:
    """
    This will launch wcf portal
    """
    def __init__(self):
        pass

    def file_not_found(self):
        """ This method """
        pg.getWindowsWithTitle("FileNet Image Viewer")[0].minimize()
        pg.getWindowsWithTitle("FileNet Framework starting page")[0].minimize()
        pg.getWindowsWithTitle("Reflection Workspace")[0].maximize()
        # Enter 35th Screen at bottom of the screen.
        ocr_for_anthem = OcrForAnthem
        boxes = ocr_for_anthem.get_gray_ocr_data()
        ck = 'Locked' in boxes['text'].unique()
        pk = 'EXT' in boxes['text'].unique()
        print(ck, pk)

        while ck is False or pk is False:  # to retake screenshots
            if ck is True and pk is False:
                print(ck, pk)
                crdnts = ocr_for_anthem.get_gray_ocr_data(text='Locked')
                a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
                pg.moveTo(a[0], a[1])
                # entering password
                Password = rfw_pwd
                for i in Password:
                    Keyboard.c.tap(i)
                    time.sleep(0.5)
                time.sleep(2)
                Keyboard.c.tap(Keyboard.keys.enter)
                time.sleep(3)
                break
            elif ck is False and pk is True:
                print(ck, pk)
                crdnts = ocr_for_anthem.get_gray_ocr_data(text='EXT')
                a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
                pg.moveTo(a[0], a[1])
                pg.click()
                Keyboard.c.press(Keyboard.keys.tab)
                Keyboard.c.release(Keyboard.keys.tab)
                Keyboard.c.press(Keyboard.keys.tab)
                Keyboard.c.release(Keyboard.keys.tab)

                command = "35"
                for j in command:
                    Keyboard.c.tap(j)
                Keyboard.c.press(Keyboard.keys.enter)
                Keyboard.c.release(Keyboard.keys.enter)
                break
            elif pk is False and ck is False:
                print(ck, pk)
                boxes = ocr_for_anthem.get_gray_ocr_data()
                ck = 'Locked' in boxes['text'].unique()
                pk = 'EXT' in boxes['text'].unique()
                continue

        # copy the IMG NBR USING IMG WORD
        boxes = ocr_for_anthem.get_word_coordinate(text='IMG')
        index = boxes[boxes.text == 'IMG'].index.values
        # copy NBR id
        NBR = boxes.iloc[index + 2].text.values[0]
        print(NBR)

        pg.getWindowsWithTitle("Reflection Workspace")[0].minimize()
        pg.getWindowsWithTitle("FileNet Image Viewer")[0].maximize()

    def detect_text(self, blng_npi, rndr_npi, state, taxid):
        x, y = pg.locateCenterOnScreen(down_key, confidence=0.8)
        pg.moveTo(x, y, duration=1)
        for i in range(0, 36):
            pg.leftClick()
        pg.moveTo(x + 10, y + 20, 1)
        screenshot = pg.screenshot(region=(0, 600, 1500, 350))
        ocr_for_anthem = OcrForAnthem.fetch_system_path()
        screenshot_path = ocr_for_anthem+ "\\1.png"
        screenshot.save(screenshot_path)
        img = cv2.imread(screenshot_path)
        photo = screenshot_path
        imgHeight, imgWidth, _ = img.shape
        print(imgHeight, imgWidth)
        client = boto3.client('rekognition', region_name='us-west-2')

        with open(photo, 'rb') as image:
            response = client.detect_text(Image={'Bytes': image.read()})

        image = Image.open(photo)
        draw = ImageDraw.Draw(image)
        lst = []
        for faceDetail in response['TextDetections']:
            # print(faceDetail["Geometry"])
            box1 = faceDetail["DetectedText"]
            lst.append(box1)
            print(box1)
        print(lst)

        if blng_npi in lst:
            ck_blng = True
        else:
            ck_blng = False

        if rndr_npi in lst:
            ck_rndr = True
        else:
            ck_rndr = False

        if state in lst:
            ck_state = True
        else:
            ck_state = False

        if taxid in lst:
            ck_tax = True
        else:
            ck_tax = False
        print(ck_blng, ck_rndr, ck_tax, ck_state)
        print(response)
        return response

    def open_wcf(self,text, blng_npi, rndr_npi, state, taxid):
        """This method launch Production F5 content portal"""
        n_dcn = text
        utility = Utility()
        utility.minimize_window(window_path="Reflection Workspace")
        # step1
        utility.maximize_window(window_path="Citrix Receiver")
        ocr_for_anthem = OcrForAnthem()
        boxes = ocr_for_anthem.get_bgr2rgb_ocr_data()
        ck = 'accept' in boxes['text'].unique()
        pk = 'Favorites' in boxes['text'].unique()
        print(ck)
        print(pk)

        while ck is False or pk is False:  # to retake screenshots
            if ck is True and pk is False:
                print(ck)
                print(pk)
                login = LoginToAnthem()
                login.login_page()
                crdnts = ocr_for_anthem.check_text_on_page(text='Favorites')
                a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
                pg.moveTo(a[0], a[1], 0.8)
                pg.click()
                time.sleep(4)  # ocr can be done only when screen get settled.
                crdnts = ocr_for_anthem.check_text_on_page(text='Production')
                a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
                pg.moveTo(a[0], a[1] - 40, 0.8)
                pg.click()
                utility.minimize_window(window_path="Citrix Receiver")
                break
            elif ck is False and pk is True:
                print(ck)
                print(pk)
                crdnts = ocr_for_anthem.check_text_on_page(text='Favorites')
                a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
                pg.moveTo(a[0], a[1], 0.8)
                pg.click()
                time.sleep(4)  # ocr can be done only when screen get settled.
                crdnts = ocr_for_anthem.check_text_on_page(text='Production')
                a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
                pg.moveTo(a[0], a[1] - 40, 0.8)
                pg.click()
                utility.minimize_window(window_path="Citrix Receiver")
                break
            elif pk is False and ck is False:
                boxes = ocr_for_anthem.check_text_on_page()
                ck = 'accept' in boxes['text'].unique()
                pk = 'Favorites' in boxes['text'].unique()
                print(ck)
                print(pk)
                continue

        # launching wcf page
        crdnts = ocr_for_anthem.check_text_on_page(text='User')
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] + 80, a[1], 1)
        pg.click()
        pg.write(citrix_id)

        # enter the password
        crdnts = ocr_for_anthem.check_text_on_page(text='Password')
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] + 80, a[1], 1)
        pg.click()
        pg.write(citrix_pwd)
        Keyboard.c.tap(Keyboard.keys.enter)

        # click on the content search

        crdnts = ocr_for_anthem.check_text_on_page(text='Content')
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0], a[1], 2)
        pg.click()
        pg.moveTo(a[0] + 100, a[1] + 115, 1)
        pg.click()
        time.sleep(0.4)
        pg.moveTo(a[0] + 100, a[1] + 85, 1)
        pg.click()

        # select claims_corro_search
        pg.moveTo(a[0] + 100, a[1] + 145, 1)
        pg.click()
        search = "Claims_Corro_Search"
        for i in search:
            Keyboard.c.tap(i)
        pg.click()

        # enter the corro
        crdnts = ocr_for_anthem.check_text_on_page(text='MEMBERCERTNUM')
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] + 300, a[1] - 50, 1)
        pg.click()
        # Iterate over the string
        for element in n_dcn:
            pg.write(element)

        # click on the browse button
        pg.moveTo(a[0] + 300, a[1] - 110, 1)
        pg.click()

        # health file/no health file found
        boxes = ocr_for_anthem.get_gray_ocr_data()
        ck = 'Content' in boxes['text'].unique()
        pk = 'HEALTH' in boxes['text'].unique()
        print(ck, pk)
        while ck is False or pk is False:  # to retake screenshots
            if ck is True and pk is False:
                print(ck, pk)
                # no file found
                print('no file found')
                self.file_not_found()
                break
            elif ck is False and pk is True:
                print(ck, pk)
                # file found
                print('file found')
                crdnts = ocr_for_anthem.check_text_on_page(text='HEALTH')
                a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
                pg.moveTo(a[0], a[1], 1)
                # pg.click()
                id1, lte = self.detect_text(blng_npi=blng_npi, rndr_npi=rndr_npi, state=state, taxid=taxid)
                print(id1, lte)
                break

            elif pk is False and ck is False:
                print(ck, pk)
                boxes = ocr_for_anthem.get_gray_ocr_data()
                ck = 'Content' in boxes['text'].unique()
                pk = 'HEALTH' in boxes['text'].unique()
                continue
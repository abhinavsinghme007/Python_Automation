"""
Importing Dependencies
"""
from ocrforanthem import OcrForAnthem
from config import *
from utility import Utility
from logintoanthem import LoginToAnthem
from imsp_one import ImspSessionOne
from imsp_two import ImspSessionTwo
import time
import re
from logger import Logger
import pyautogui as pg
from ..input_controller.keyboard import Keyboard


class LaunchCitrixChrome(ImspSessionOne):
    """
    This class will launch Google Chrome through Citrix gateway and launch CIW portal, extract claims details
    """
    def __init__(self):
        self.log = Logger(self.__class__.__name__)

    def citrix_chrome(self):
        """
        This method will open chrome and launch ciw portal
        :return:
        """
        utility = Utility()
        ocr_for_anthem = OcrForAnthem()
        utility.maximize_window(window_path="Citrix Receiver")
        boxes = ocr_for_anthem.get_ocr_data()
        ck = 'accept' in boxes['text'].unique()
        pk = 'Favorites' in boxes['text'].unique()
        print(ck)
        print(pk)

        while ck is False or pk is False:  # to retake screenshots
            if ck is True and pk is False:
                print(ck)
                print(pk)
                login_to_anthem = LoginToAnthem()
                login_to_anthem.login_page()
                ocr_for_anthem.move_cursor_to_text(Dict["Citrix_Receiver"][0])
                time.sleep(4)
                crdnts = ocr_for_anthem.check_text_on_page(text=Dict["Citrix_Receiver"][3])
                a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
                pg.moveTo(a[0] + 10, a[1] - 40, 0.5)
                pg.click()
                utility.minimize_window(window_path="Citrix Receiver")
                break
            elif ck is False and pk is True:
                print(ck)
                print(pk)
                ocr_for_anthem.move_cursor_to_text('Favorites')
                time.sleep(4)  # ocr can be done only when screen get settled.
                crdnts = ocr_for_anthem.check_text_on_page(text='Google')
                a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
                pg.moveTo(a[0] + 15, a[1] - 30, 0.5)
                pg.click()
                utility.minimize_window(window_path="Citrix Receiver")
                break
            elif pk is False and ck is False:
                boxes = ocr_for_anthem.get_ocr_data()
                ck = 'accept' in boxes['text'].unique()
                pk = 'Favorites' in boxes['text'].unique()
                print(ck)
                print(pk)
                continue
        utility.minimize_window(window_path="Reflection Workspace")
        ocr_for_anthem.move_cursor_to_text(text=Dict["ciw"][1])
        time.sleep(1)
        with Keyboard.c.pressed(Keyboard.keys.ctrl):
            Keyboard.c.tap('t')
        time.sleep(1)
        pg.typewrite(ciw_url, interval=0.02)  # shooting the web link of anthem
        Keyboard.c.tap(Keyboard.keys.enter)

    def claims_examiner(self):
        """
        This method will search claims by putting DCN id and will fetch and extract the details
        :return:
        """
        # enter the username
        ocr_for_anthem = OcrForAnthem()
        ocr_for_anthem.move_cursor_to_text(Dict["claims"][0])
        pg.write(ciw_id)

        # enter the password
        ocr_for_anthem.move_cursor_to_text(Dict["claims"][1])
        pg.write(ciw_pwd)
        Keyboard.c.tap(Keyboard.keys.enter)

        # click on NO
        crdnts = ocr_for_anthem.get_threshold_ocr_data(text=Dict["claims"][5])
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] - 1013, a[1] + 83, 1)
        pg.click()
        time.sleep(0.5)
        pg.moveTo(a[0] + 30, a[1] + 127, 1)
        pg.click()

        # click on CI&W
        crdnts = ocr_for_anthem.check_text_on_page(text=Dict["ciw"][4])
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] - 108, a[1] + 140, 1)
        pg.click()

        # click on claims
        pg.moveTo(a[0] - 30, a[1] + 210, 1)
        pg.click()
        pg.click(700, 1000, 1)

        # click on CI&W
        crdnts = ocr_for_anthem.check_text_on_page(text='DCN')
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0], a[1] + 30, 1)
        pg.click()

        # write dcn here
        copy_dcn = ImspSessionOne().copy_dcn()
        pg.write(copy_dcn.dcn)
        Keyboard.c.tap(Keyboard.keys.enter)

        # click on the claims from search result
        crdnts = ocr_for_anthem.check_text_on_page(text='YDCN')
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0], a[1] + 40, 1)
        pg.click()
        time.sleep(2)
        Keyboard.c.tap(Keyboard.keys.page_down)

    def copy_tbr_id(self):
        """ This method will copy taxid, Billing NPI, Rendering NPI using ocr"""
        # copy tax id
        ocr_for_anthem = OcrForAnthem()
        search_tax_id = ImspSessionOne.copy_dcn()
        boxes = ocr_for_anthem.get_word_coordinate(text=search_tax_id.tax_id_1)
        index = boxes[boxes.text == search_tax_id.tax_id_1].index.values
        self.tax_id_2 = boxes.iloc[index].text.values[0]
        print(self.tax_id_2)

        # copy Rendering NPI
        search_rndr_npi = ImspSessionOne.copy_dcn()
        if search_rndr_npi.rndr_npi_1 != "":
            boxes = ocr_for_anthem.get_word_coordinate(text=search_rndr_npi.rndr_npi_1)
            index = boxes[boxes.text == search_rndr_npi.rndr_npi_1].index.values
            self.rndr_npi_2 = boxes.iloc[index].text.values[0]
            print(self.rndr_npi_2)
        else:
            self.rndr_npi_2 = search_rndr_npi.rndr_npi_1
            print(self.rndr_npi_2)

        # copy Billing NPI
        search_blng_npi = ImspSessionOne.copy_dcn()
        boxes = ocr_for_anthem.get_word_coordinate(text=search_blng_npi.blng_npi_1)
        index = boxes[boxes.text == search_blng_npi.blng_npi_1].index.values
        self.blng_npi_2 = boxes.iloc[index].text.values[0]
        print(self.blng_npi_2)

        # click on open claim detail
        x, y = pg.locateCenterOnScreen(click_on_open_claim_details, confidence=0.8)
        pg.moveTo(x, y, duration=1)
        pg.click()
        crdnts = ocr_for_anthem.check_text_on_page(text='Resolution')
        for i in range(7):
            Keyboard.c.tap(Keyboard.keys.page_down)
            time.sleep(0.5)

        crdnts = ocr_for_anthem.check_text_on_page(text='Attachments')
        a = ocr_for_anthem.word_coordinate(coordinates=crdnts)
        pg.moveTo(a[0] - 712, a[1], 1)
        pg.click()
        time.sleep(1)
        Keyboard.c.tap(Keyboard.keys.page_down)

        boxes = ocr_for_anthem.get_word_coordinate(text='32.')
        index = boxes[boxes.text == '32.'].index.values
        self.state_name = boxes.iloc[index + 16].text.values[0]
        self.state_name = re.sub(',', '', self.state_name)
        print(self.state_name)

        self.natl_state2 = boxes.iloc[index + 17].text.values[0]
        print(self.natl_state2)

        self.zip_code = boxes.iloc[index + 18].text.values[0]
        self.zip_code = self.zip_code[0:5]
        print(self.zip_code)
        time.sleep(2)
        pg.getActiveWindow().minimize()

    def validate_dsscreen(self):
        """
        This method will validate the Tax Id, Rendering NPI and Billing NPI extracted from reflection workspace and claim image
        :return:
        """
        search_tax_id = ImspSessionOne.copy_dcn()
        if search_tax_id.tax_id_1 == self.tax_id_2:
            self.tax_id = search_tax_id.tax_id_1
            print(self.tax_id)
        else:
            print('Tax ID doesnt matched')

        search_rndr_npi = ImspSessionOne.copy_dcn()
        if search_rndr_npi.rndr_npi_1 == self.rndr_npi_2:
            self.rndr_npi = self.rndr_npi_2
            print(self.rndr_npi)
        else:
            print('Rendering NPI doesnt matched')

        search_blng_npi = ImspSessionOne.copy_dcn()
        if search_blng_npi.blng_npi_1 == self.blng_npi_2:
            self.blng_npi = self.blng_npi_2
            print(self.blng_npi)
        else:
            print('Billing NPI doesnt matched')

    def natl_state_check(self):
        """ This method will validate National state information"""
        search_natl_state = ImspSessionTwo.supporting_data_screen()
        if search_natl_state.natl_state1 == self.natl_state2:
            self.natl_state = search_natl_state.natl_state1
            print(self.natl_state)
        else:
            print('NATL STATE DOESNT MATCHED')

    def run(self):
        self.citrix_chrome()
        self.claims_examiner()
        self.copy_tbr_id()
        self.validate_dsscreen()
        self.natl_state_check()

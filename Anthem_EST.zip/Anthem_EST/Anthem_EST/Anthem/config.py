"""credentials"""

citrix_id = 'ah62364'
citrix_pwd = 'Anthem@24'
auth_code = '4'
rfw_id = 'ah62364'
rfw_pwd = 'Anthem@1'
ciw_id = 'ah62364'
ciw_pwd = 'Anthem@24'

"""defining variables"""

chrome_path = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
anthem_url = 'https://partnergw.elevancehealth.com/logon/LogonPoint/index.html'
pingid_path = "C:\\Program Files (x86)\\Ping Identity\\PingID\\PingID.exe"
ciw_url = 'https://ciw.antheminc.com/prweb/PRWebLDAP3/app/CIW_/BEJwBQgQLi3Zc6_aYMHeXdv7jIKpLQqi*/!STANDARD?pzPostData=1683441389'
plm_url = 'https://sps.anthem.com/prweb/sso1/QENveJzV73q49KDalajnu1NmWWgiJRi9*/!STANDARD?pzPostData=-1310714478&pzPostData=-865131085'
tesseract_path =r"C:\Users\Ganesh.Mandpe\AppData\Local\Tesseract-OCR\tesseract.exe"
dcn_datasheet = r"C:\Users\ganesh.mandpe\pythonProject\Anthem_EST\Documents\dcn_datasheet.xlsx"
click_on_open_claim_details = r'C:\Users\ganesh.mandpe\MyProject\PythonProject\AnthemProject\images\open_claim_detail.png'
down_key = r"C:\Users\ganesh.mandpe\pythonProject\Anthem_EST\Images\down_key.png"

"""dictionary for keywords"""

Dict = {"login": ['Logon', 'VA', '@l'], "select_auth_device": ['4.Desktop', 'Submit', '5.Desktop'],
        "launch_pingID": ['Copy', 'Ping', 'PingID'],
        "Passcode": ['Submit', 'passcode.'], "Citrix_Receiver": ['Favorites', 'Workspace', 'Production', 'Google'],
        "winca": ['Documents', 'Recent', 'New', 'Tab'], "ssl": ['ISM', 'BLUE', 'CROSS'], "super_session": ['Userid:'],
        "imsp": ['IMSP', 'IMSP#1', 'IMSP#2', 'ATPA'],
        "pause_break": ['/SIGN'], "session1": ['oOpTION', 'CUSTMRO1', 'OPTION', 'OPTION:'],
        "Filenet": ['Caims_Corra', 'Select', 'Search', 'Gaims_Corro_Search', 'MEMBERCERTHUM'],
        "ciw": ['pulse.elevancehealth.com/v3/home', 'DFD-Pulse', '+Pulse', 'Examiner', 'Dashboard', 'QB'],
        "claims": ['User', 'Password', 'Login', 'No', 'Submit', 'overtime']}
